class User {
  String? name;

  User({this.name});
}