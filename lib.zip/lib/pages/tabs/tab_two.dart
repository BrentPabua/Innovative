import 'package:flutter/material.dart';

class Pabua {
  int? age;
  String? image;
  String? name;
  String? relationship;
  String? occupation;
  String? birthday;

  Pabua({
    @required this.image,
    @required this.name,
    @required this.relationship,
    @required this.occupation,
    @required this.age,
    @required this.birthday,
  });
}
List<Pabua> detailList = [
  Pabua (
    image: "assets/BrentPabua.jpg",
    name: "Brent Joshua T. Pabua",
    relationship:"Me",
    occupation: "Student",
    birthday: "October 26, 1997",
    age: 25,

  ),
  Pabua (
  image: "assets/BrentPabua.jpg",
  name: "Brent Joshua T. Pabua",
  relationship:"Me",
  occupation: "Student",
  birthday: "October 26, 1997",
  age: 25,

  ),

  Pabua (
  image: "assets/BrentPabua.jpg",
  name: "Brent Joshua T. Pabua",
  relationship:"Me",
  occupation: "Student",
  birthday: "October 26, 1997",
  age: 25,
];