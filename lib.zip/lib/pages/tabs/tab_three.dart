import 'package:flutter/material.dart';
import 'package:innovative_task/pages/tabs/tab_two.dart';

class RoutingPage extends StatelessWidget {
  final Pabua details ;

  const RoutingPage(this.details,  {super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Brent Pabua'),
        

      ),



    );
  }
}
